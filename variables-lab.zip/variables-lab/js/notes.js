console.log(`Hello world!`);
console.log(123 / 456);

//Declare a variable (can be modified)
//A variable is a keyword that can be used to reference a value
//Think of it as a container that holds value
// A variable is like a named container
// Change what's in the container using the assignment operator: =
// Single Line comment
/* Multi line comment */

/* TO DO:
- Output to the document
- Difference ways to declare variables
  - Store a reference
- The difference between string quotes
- JavaScript resources
- If there's time: The difference between string quotes
- if there's time: functions
- https://github.com/rlx310/L_Javascript_Duckett_Interactive-Front-End-Web-Development_Edition-1/blob/master/JavaScript%20and%20JQuery%20Interactive%20Front-En%20-%20Jon%20Duckett.pdf
- https://eloquentjavascript.net/Eloquent_JavaScript.pdf
- https://eloquentjavascript.net/
- https://developer.mozilla.org/en-US/
- http://javascript.info/
- codecademy.com
- 

*/



let myName = `George Brown`; // String
let balance = 0; // Number

console.log(myName); // 0
console.log(balance); // 0

console.log(`Hello, ${ myName }!`)

let balance = 0;
//Your balance is 0
console.log(`Your balance is ${balance}.`);

balance = balance + 100;
//Your balance is 100
console.log(`Your balance is ${balance}.`);

balance = balance - 20;
//Your balance is 80
console.log(`Your balance is ${balance}.`);

//If I deposit $40, then I would have: $120
let deposit = 120;
console.log(`If I deposit ${deposit}, then I would have: ${balance + deposit}`);

// + - * / ** % = 
// += -= *= /=

let numItemsInCart = 0;

numItemsInCart = numItemsInCart + 1; // Add 1
numItemsInCart += 1; // Add 1

console.log(numItemsInCart);

/* 
- IDs are aleays unique
- let and var are always identical
*/

// + - * / ** % = 
// += -= *= /=

let numItemsInCart = 0;
let nameOfUser = `George Brown`;


numItemsInCart += 1; // Add 1
numItemsInCart += 1; // Add 1
numItemsInCart += 1; // Add 1

document.getElementById(`cartItems`).innerHTML = numItemsInCart;

// Search the document
// Find the element with id="theHeading"
// Check the innerHTML
document.getElementById(`theHeading`).innerHTML = `Hello, <small class="highlight">${nameOfUser}</small>`; 