console.log(`Hello world!`);
console.log(123 / 456);

//Declare a variable (can be modified)
//A variable is a keyword that can be used to reference a value
//Think of it as a container that holds value
// A variable is like a named container
// Change what's in the container using the assignment operator: =
// Single Line comment
/* Multi line comment */



let balance = 0;
//Your balance is 0
console.log(`Your balance is ${balance}.`);

balance = balance + 100;
//Your balance is 100
console.log(`Your balance is ${balance}.`);

balance = balance - 20;
//Your balance is 80
console.log(`Your balance is ${balance}.`);

//If I deposit $40, then I would have: $120
let deposit = 120;
console.log(`If I deposit ${deposit}, then I would have: ${balance} + ${deposit}`);